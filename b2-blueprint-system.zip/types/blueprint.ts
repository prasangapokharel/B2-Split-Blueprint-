export interface Dimension {
  value: number
  unit: "ft" | "m" | "in" | "cm"
  label: string
}

export interface Component {
  id: string
  name: string
  position: { x: number; y: number }
  dimensions: { width: number; height: number }
  description: string
  specifications: Record<string, string>
  subsystems?: Component[]
}

export interface BlueprintLayer {
  id: string
  name: string
  visible: boolean
  color: string
  components: Component[]
}

export interface BlueprintView {
  id: string
  name: string
  viewBox: string
  scale: number
  layers: BlueprintLayer[]
}

export interface TechnicalSpec {
  category: string
  items: Array<{
    label: string
    value: string
    unit?: string
  }>
}
