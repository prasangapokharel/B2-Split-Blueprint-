"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Layers, Ruler, Settings, Eye, EyeOff, RotateCcw, Download, Grid3X3 } from "lucide-react"

import { BlueprintGrid } from "./components/blueprint-grid"
import { DimensionLine } from "./components/dimension-line"
import { ComponentCallout } from "./components/component-callout"
import { technicalSpecs, blueprintLayers } from "./data/b2-specifications"
import type { Component } from "./types/blueprint"

export default function B2Blueprint() {
  const [activeView, setActiveView] = useState("top")
  const [layers, setLayers] = useState(blueprintLayers)
  const [selectedComponent, setSelectedComponent] = useState<Component | null>(null)
  const [scale, setScale] = useState([100])
  const [showGrid, setShowGrid] = useState(true)
  const [showDimensions, setShowDimensions] = useState(true)

  const toggleLayer = useCallback((layerId: string) => {
    setLayers((prev) => prev.map((layer) => (layer.id === layerId ? { ...layer, visible: !layer.visible } : layer)))
  }, [])

  const handleComponentClick = useCallback((component: Component) => {
    setSelectedComponent(component)
  }, [])

  const scaleValue = scale[0] / 100

  // B-2 outline path (simplified for top view)
  const b2OutlinePath = `
    M 400 100
    L 200 300
    L 250 350
    L 350 320
    L 400 330
    L 450 320
    L 550 350
    L 600 300
    L 400 100
    Z
  `

  // Wing structure paths
  const wingStructure = [
    "M 400 100 L 200 300 L 250 320 L 400 150 Z", // Left wing
    "M 400 100 L 600 300 L 550 320 L 400 150 Z", // Right wing
    "M 350 150 L 450 150 L 450 320 L 350 320 Z", // Center body
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Grid3X3 className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">B-2 Spirit Technical Blueprint</h1>
              <p className="text-slate-400">Production-Level Engineering Drawings</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export DWG
            </Button>
            <Button variant="outline" size="sm">
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset View
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Main Blueprint Area */}
          <div className="xl:col-span-3">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-blue-400">Technical Drawing - Top View</CardTitle>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-slate-400">Scale:</span>
                      <div className="w-32">
                        <Slider
                          value={scale}
                          onValueChange={setScale}
                          min={50}
                          max={200}
                          step={10}
                          className="w-full"
                        />
                      </div>
                      <span className="text-sm text-slate-400 w-12">{scale[0]}%</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Switch checked={showGrid} onCheckedChange={setShowGrid} id="grid-toggle" />
                      <label htmlFor="grid-toggle" className="text-sm text-slate-400">
                        Grid
                      </label>
                    </div>

                    <div className="flex items-center gap-2">
                      <Switch checked={showDimensions} onCheckedChange={setShowDimensions} id="dimensions-toggle" />
                      <label htmlFor="dimensions-toggle" className="text-sm text-slate-400">
                        Dimensions
                      </label>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-0">
                <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
                  <svg viewBox="0 0 800 400" className="w-full h-[600px]" style={{ transform: `scale(${scaleValue})` }}>
                    {/* Grid */}
                    {showGrid && <BlueprintGrid width={800} height={400} gridSize={10} majorGridSize={50} />}

                    {/* Title Block */}
                    <g className="title-block">
                      <rect x="600" y="20" width="180" height="80" fill="none" stroke="#334155" strokeWidth="1" />
                      <text x="610" y="35" fill="#60a5fa" fontSize="12" className="font-bold">
                        NORTHROP GRUMMAN B-2 SPIRIT
                      </text>
                      <text x="610" y="50" fill="#94a3b8" fontSize="8">
                        STRATEGIC STEALTH BOMBER
                      </text>
                      <text x="610" y="65" fill="#94a3b8" fontSize="8">
                        SCALE: 1:500 | DRAWING NO: B2-001
                      </text>
                      <text x="610" y="80" fill="#94a3b8" fontSize="8">
                        DATE: {new Date().toLocaleDateString()}
                      </text>
                      <text x="610" y="95" fill="#94a3b8" fontSize="8">
                        SHEET 1 OF 1
                      </text>
                    </g>

                    {/* Aircraft Outline */}
                    <path d={b2OutlinePath} fill="none" stroke="#60a5fa" strokeWidth="2" className="aircraft-outline" />

                    {/* Wing Structure */}
                    {wingStructure.map((path, index) => (
                      <path
                        key={index}
                        d={path}
                        fill="rgba(96, 165, 250, 0.1)"
                        stroke="#60a5fa"
                        strokeWidth="1"
                        strokeDasharray="3,3"
                      />
                    ))}

                    {/* Center Line */}
                    <line
                      x1="400"
                      y1="50"
                      x2="400"
                      y2="350"
                      stroke="#34d399"
                      strokeWidth="1"
                      strokeDasharray="5,5"
                      opacity="0.7"
                    />
                    <text x="405" y="200" fill="#34d399" fontSize="8" className="font-mono">
                      ℄
                    </text>

                    {/* Dimensions */}
                    {showDimensions && (
                      <>
                        <DimensionLine
                          x1={200}
                          y1={300}
                          x2={600}
                          y2={300}
                          label="172'-0 WINGSPAN"
                          offset={-40}
                          color="#fbbf24"
                        />
                        <DimensionLine
                          x1={400}
                          y1={100}
                          x2={400}
                          y2={330}
                          label="69'-0 LENGTH"
                          offset={60}
                          color="#fbbf24"
                        />
                      </>
                    )}

                    {/* Layer Components */}
                    {layers
                      .filter((layer) => layer.visible)
                      .map((layer) => (
                        <g key={layer.id} className={`layer-${layer.id}`}>
                          {layer.components.map((component) => (
                            <g key={component.id}>
                              {/* Component outline */}
                              <rect
                                x={component.position.x - component.dimensions.width / 2}
                                y={component.position.y - component.dimensions.height / 2}
                                width={component.dimensions.width}
                                height={component.dimensions.height}
                                fill={`${layer.color}20`}
                                stroke={layer.color}
                                strokeWidth="1"
                                className="cursor-pointer hover:fill-opacity-40 transition-all"
                                onClick={() => handleComponentClick(component)}
                              />

                              {/* Component callout */}
                              <ComponentCallout
                                x={component.position.x}
                                y={component.position.y}
                                label={component.name}
                                description={component.description}
                                specifications={component.specifications}
                                isActive={selectedComponent?.id === component.id}
                                onClick={() => handleComponentClick(component)}
                              />
                            </g>
                          ))}
                        </g>
                      ))}

                    {/* Reference Points */}
                    <g className="reference-points">
                      <circle cx="400" cy="100" r="2" fill="#ef4444" />
                      <text x="405" y="95" fill="#ef4444" fontSize="8">
                        NOSE
                      </text>

                      <circle cx="200" cy="300" r="2" fill="#ef4444" />
                      <text x="160" y="295" fill="#ef4444" fontSize="8">
                        PORT WINGTIP
                      </text>

                      <circle cx="600" cy="300" r="2" fill="#ef4444" />
                      <text x="605" y="295" fill="#ef4444" fontSize="8">
                        STBD WINGTIP
                      </text>
                    </g>
                  </svg>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Control Panel */}
          <div className="space-y-6">
            {/* Layer Controls */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  Drawing Layers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {layers.map((layer) => (
                  <div key={layer.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded" style={{ backgroundColor: layer.color }} />
                      <span className="text-sm">{layer.name}</span>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => toggleLayer(layer.id)} className="p-1">
                      {layer.visible ? (
                        <Eye className="h-4 w-4 text-green-400" />
                      ) : (
                        <EyeOff className="h-4 w-4 text-slate-500" />
                      )}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Component Details */}
            {selectedComponent && (
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-yellow-400 flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Component Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-white mb-1">{selectedComponent.name}</h4>
                    <p className="text-sm text-slate-400 mb-3">{selectedComponent.description}</p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-sm font-semibold text-slate-300">Specifications:</h5>
                    {Object.entries(selectedComponent.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between text-sm">
                        <span className="text-slate-400">{key}:</span>
                        <span className="text-white">{value}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-700">
                    <div className="text-xs text-slate-500">
                      Position: ({selectedComponent.position.x}, {selectedComponent.position.y})
                    </div>
                    <div className="text-xs text-slate-500">
                      Size: {selectedComponent.dimensions.width} × {selectedComponent.dimensions.height}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Technical Specifications */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <Ruler className="h-5 w-5" />
                  Technical Specifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="general" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                    <TabsTrigger value="general" className="text-xs">
                      General
                    </TabsTrigger>
                    <TabsTrigger value="performance" className="text-xs">
                      Performance
                    </TabsTrigger>
                    <TabsTrigger value="propulsion" className="text-xs">
                      Propulsion
                    </TabsTrigger>
                  </TabsList>

                  {technicalSpecs.map((spec, index) => (
                    <TabsContent key={index} value={spec.category.toLowerCase().split(" ")[0]} className="space-y-2">
                      {spec.items.map((item, itemIndex) => (
                        <div key={itemIndex} className="flex justify-between text-sm">
                          <span className="text-slate-400">{item.label}:</span>
                          <span className="text-white">
                            {item.value} {item.unit && <span className="text-slate-500">{item.unit}</span>}
                          </span>
                        </div>
                      ))}
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
