import type { TechnicalSpec, Component, BlueprintLayer } from "../types/blueprint"

export const technicalSpecs: TechnicalSpec[] = [
  {
    category: "General Characteristics",
    items: [
      { label: "Crew", value: "2", unit: "pilots" },
      { label: "Length", value: "69", unit: "ft" },
      { label: "Wingspan", value: "172", unit: "ft" },
      { label: "Height", value: "17", unit: "ft" },
      { label: "Wing Area", value: "5,140", unit: "sq ft" },
      { label: "Empty Weight", value: "160,000", unit: "lbs" },
      { label: "Max Takeoff Weight", value: "336,500", unit: "lbs" },
    ],
  },
  {
    category: "Performance",
    items: [
      { label: "Maximum Speed", value: "630", unit: "mph" },
      { label: "Cruise Speed", value: "560", unit: "mph" },
      { label: "Range", value: "6,000", unit: "nmi" },
      { label: "Service Ceiling", value: "50,000", unit: "ft" },
      { label: "Rate of Climb", value: "6,000", unit: "ft/min" },
    ],
  },
  {
    category: "Propulsion",
    items: [
      { label: "Engines", value: "4", unit: "× F118-GE-100" },
      { label: "Thrust per Engine", value: "17,300", unit: "lbf" },
      { label: "Total Thrust", value: "69,200", unit: "lbf" },
      { label: "Fuel Capacity", value: "167,000", unit: "lbs" },
    ],
  },
]

export const cockpitComponents: Component[] = [
  {
    id: "pilot-left",
    name: "Pilot Station (Left)",
    position: { x: 380, y: 180 },
    dimensions: { width: 25, height: 30 },
    description: "Primary pilot control station with full flight controls",
    specifications: {
      Controls: "Stick and rudder pedals",
      Displays: "4 × MFDs, HUD",
      Systems: "Flight management, navigation",
    },
  },
  {
    id: "pilot-right",
    name: "Mission Commander (Right)",
    position: { x: 420, y: 180 },
    dimensions: { width: 25, height: 30 },
    description: "Mission commander station with weapons systems",
    specifications: {
      Controls: "Mission systems, weapons",
      Displays: "4 × MFDs, tactical displays",
      Systems: "Radar, EW, communications",
    },
  },
]

export const engineComponents: Component[] = [
  {
    id: "engine-1",
    name: "Engine #1 (Port Outboard)",
    position: { x: 200, y: 280 },
    dimensions: { width: 40, height: 60 },
    description: "General Electric F118-GE-100 turbofan engine",
    specifications: {
      Type: "Non-afterburning turbofan",
      Thrust: "17,300 lbf",
      "Bypass Ratio": "5.4:1",
      Length: "185 in",
    },
  },
  {
    id: "engine-2",
    name: "Engine #2 (Port Inboard)",
    position: { x: 320, y: 280 },
    dimensions: { width: 40, height: 60 },
    description: "General Electric F118-GE-100 turbofan engine",
    specifications: {
      Type: "Non-afterburning turbofan",
      Thrust: "17,300 lbf",
      "Bypass Ratio": "5.4:1",
      Length: "185 in",
    },
  },
  {
    id: "engine-3",
    name: "Engine #3 (Starboard Inboard)",
    position: { x: 480, y: 280 },
    dimensions: { width: 40, height: 60 },
    description: "General Electric F118-GE-100 turbofan engine",
    specifications: {
      Type: "Non-afterburning turbofan",
      Thrust: "17,300 lbf",
      "Bypass Ratio": "5.4:1",
      Length: "185 in",
    },
  },
  {
    id: "engine-4",
    name: "Engine #4 (Starboard Outboard)",
    position: { x: 600, y: 280 },
    dimensions: { width: 40, height: 60 },
    description: "General Electric F118-GE-100 turbofan engine",
    specifications: {
      Type: "Non-afterburning turbofan",
      Thrust: "17,300 lbf",
      "Bypass Ratio": "5.4:1",
      Length: "185 in",
    },
  },
]

export const weaponsBayComponents: Component[] = [
  {
    id: "weapons-bay-1",
    name: "Forward Weapons Bay",
    position: { x: 350, y: 220 },
    dimensions: { width: 100, height: 40 },
    description: "Primary weapons bay with rotary launcher",
    specifications: {
      Capacity: "16 × B61 or 16 × B83",
      Launcher: "Rotary launcher assembly",
      Length: "40 ft",
      Width: "12 ft",
    },
  },
  {
    id: "weapons-bay-2",
    name: "Aft Weapons Bay",
    position: { x: 350, y: 270 },
    dimensions: { width: 100, height: 40 },
    description: "Secondary weapons bay with conventional ordnance",
    specifications: {
      Capacity: "80 × Mk 82 or 16 × Mk 84",
      Launcher: "Bomb rack assembly",
      Length: "40 ft",
      Width: "12 ft",
    },
  },
]

export const blueprintLayers: BlueprintLayer[] = [
  {
    id: "structure",
    name: "Airframe Structure",
    visible: true,
    color: "#60a5fa",
    components: [],
  },
  {
    id: "cockpit",
    name: "Cockpit Systems",
    visible: true,
    color: "#34d399",
    components: cockpitComponents,
  },
  {
    id: "engines",
    name: "Propulsion Systems",
    visible: true,
    color: "#f59e0b",
    components: engineComponents,
  },
  {
    id: "weapons",
    name: "Weapons Systems",
    visible: true,
    color: "#ef4444",
    components: weaponsBayComponents,
  },
  {
    id: "avionics",
    name: "Avionics & Electronics",
    visible: false,
    color: "#8b5cf6",
    components: [],
  },
  {
    id: "fuel",
    name: "Fuel Systems",
    visible: false,
    color: "#06b6d4",
    components: [],
  },
]
