import B2Blueprint from "../b2-blueprint"

export default function Page() {
  return <B2Blueprint />
}
