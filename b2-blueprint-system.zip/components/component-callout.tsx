"use client"

interface ComponentCalloutProps {
  x: number
  y: number
  label: string
  description: string
  specifications?: Record<string, string>
  isActive: boolean
  onClick: () => void
}

export function ComponentCallout({
  x,
  y,
  label,
  description,
  specifications,
  isActive,
  onClick,
}: ComponentCalloutProps) {
  return (
    <g className="component-callout cursor-pointer" onClick={onClick}>
      {/* Callout point */}
      <circle
        cx={x}
        cy={y}
        r="3"
        fill={isActive ? "#fbbf24" : "#60a5fa"}
        stroke="#1e293b"
        strokeWidth="1"
        className="hover:fill-yellow-400 transition-colors"
      />

      {/* Leader line */}
      <line
        x1={x}
        y1={y}
        x2={x + 50}
        y2={y - 30}
        stroke={isActive ? "#fbbf24" : "#60a5fa"}
        strokeWidth="1"
        strokeDasharray="2,2"
      />

      {/* Label background */}
      <rect
        x={x + 55}
        y={y - 45}
        width="120"
        height="30"
        fill="#1e293b"
        stroke={isActive ? "#fbbf24" : "#60a5fa"}
        strokeWidth="1"
        rx="3"
        className="opacity-90"
      />

      {/* Label text */}
      <text x={x + 65} y={y - 32} fill="white" fontSize="9" className="font-semibold">
        {label}
      </text>
      <text x={x + 65} y={y - 22} fill="#94a3b8" fontSize="7">
        {description.substring(0, 20)}...
      </text>

      {/* Hover indicator */}
      {isActive && (
        <circle cx={x} cy={y} r="8" fill="none" stroke="#fbbf24" strokeWidth="2" className="animate-pulse" />
      )}
    </g>
  )
}
