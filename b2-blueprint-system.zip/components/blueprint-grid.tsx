interface BlueprintGridProps {
  width: number
  height: number
  gridSize: number
  majorGridSize: number
}

export function BlueprintGrid({ width, height, gridSize, majorGridSize }: BlueprintGridProps) {
  const minorLines = []
  const majorLines = []

  // Vertical lines
  for (let x = 0; x <= width; x += gridSize) {
    const isMajor = x % majorGridSize === 0
    const line = (
      <line
        key={`v-${x}`}
        x1={x}
        y1={0}
        x2={x}
        y2={height}
        stroke={isMajor ? "#334155" : "#1e293b"}
        strokeWidth={isMajor ? "0.5" : "0.25"}
        opacity={isMajor ? "0.8" : "0.4"}
      />
    )

    if (isMajor) {
      majorLines.push(line)
    } else {
      minorLines.push(line)
    }
  }

  // Horizontal lines
  for (let y = 0; y <= height; y += gridSize) {
    const isMajor = y % majorGridSize === 0
    const line = (
      <line
        key={`h-${y}`}
        x1={0}
        y1={y}
        x2={width}
        y2={y}
        stroke={isMajor ? "#334155" : "#1e293b"}
        strokeWidth={isMajor ? "0.5" : "0.25"}
        opacity={isMajor ? "0.8" : "0.4"}
      />
    )

    if (isMajor) {
      majorLines.push(line)
    } else {
      minorLines.push(line)
    }
  }

  return (
    <g className="blueprint-grid">
      {minorLines}
      {majorLines}
    </g>
  )
}
