interface DimensionLineProps {
  x1: number
  y1: number
  x2: number
  y2: number
  label: string
  offset?: number
  color?: string
}

export function DimensionLine({ x1, y1, x2, y2, label, offset = 20, color = "#60a5fa" }: DimensionLineProps) {
  const midX = (x1 + x2) / 2
  const midY = (y1 + y2) / 2
  const angle = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI

  // Calculate perpendicular offset
  const perpAngle = ((angle + 90) * Math.PI) / 180
  const offsetX = Math.cos(perpAngle) * offset
  const offsetY = Math.sin(perpAngle) * offset

  const lineX1 = x1 + offsetX
  const lineY1 = y1 + offsetY
  const lineX2 = x2 + offsetX
  const lineY2 = y2 + offsetY

  return (
    <g className="dimension-line">
      {/* Extension lines */}
      <line x1={x1} y1={y1} x2={lineX1} y2={lineY1} stroke={color} strokeWidth="0.5" />
      <line x1={x2} y1={y2} x2={lineX2} y2={lineY2} stroke={color} strokeWidth="0.5" />

      {/* Dimension line */}
      <line x1={lineX1} y1={lineY1} x2={lineX2} y2={lineY2} stroke={color} strokeWidth="1" />

      {/* Arrowheads */}
      <polygon
        points={`${lineX1 - 3},${lineY1 - 2} ${lineX1 + 3},${lineY1} ${lineX1 - 3},${lineY1 + 2}`}
        fill={color}
      />
      <polygon
        points={`${lineX2 + 3},${lineY2 - 2} ${lineX2 - 3},${lineY2} ${lineX2 + 3},${lineY2 + 2}`}
        fill={color}
      />

      {/* Label */}
      <text
        x={midX + offsetX}
        y={midY + offsetY - 5}
        fill={color}
        fontSize="10"
        textAnchor="middle"
        className="font-mono"
      >
        {label}
      </text>
    </g>
  )
}
